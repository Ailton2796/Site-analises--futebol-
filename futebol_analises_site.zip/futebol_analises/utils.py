import numpy as np

def calcular_estatisticas(df, time):
    ultimos_jogos = df[(df['time_casa'] == time) | (df['time_fora'] == time)].sort_values(by='data', ascending=False).head(5)
    
    gols_marcados = []
    gols_sofridos = []

    for _, row in ultimos_jogos.iterrows():
        if row['time_casa'] == time:
            gols_marcados.append(row['gols_casa'])
            gols_sofridos.append(row['gols_fora'])
        else:
            gols_marcados.append(row['gols_fora'])
            gols_sofridos.append(row['gols_casa'])

    return {
        'media_gols_marcados': np.mean(gols_marcados),
        'media_gols_sofridos': np.mean(gols_sofridos),
        'jogos': ultimos_jogos.to_dict(orient='records')
    }

def prever_resultado(modelo, estat_casa, estat_fora):
    X = [[
        estat_casa['media_gols_marcados'],
        estat_casa['media_gols_sofridos'],
        estat_fora['media_gols_marcados'],
        estat_fora['media_gols_sofridos']
    ]]
    return modelo.predict_proba(X)[0]