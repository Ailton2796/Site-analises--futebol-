import streamlit as st
import pandas as pd
import pickle
from utils import calcular_estatisticas, prever_resultado

# Carrega o modelo
with open("modelo/modelo_treinado.pkl", "rb") as f:
    modelo = pickle.load(f)

# Carrega dados
dados = pd.read_csv("dados/historico_jogos.csv")

st.title("🔍 Análises de Futebol com Probabilidades Reais")

# Seleção de times
times = sorted(dados['time_casa'].unique())
time_casa = st.selectbox("Time da Casa", times)
time_fora = st.selectbox("Time Visitante", times)

if time_casa and time_fora and time_casa != time_fora:
    st.subheader("📊 Estatísticas dos Times")
    
    estat_casa = calcular_estatisticas(dados, time_casa)
    estat_fora = calcular_estatisticas(dados, time_fora)

    st.write("**Time da Casa:**", estat_casa)
    st.write("**Time Visitante:**", estat_fora)

    st.subheader("📈 Previsão da Partida")
    probs = prever_resultado(modelo, estat_casa, estat_fora)

    st.success(f"🟩 Vitória do {time_casa}: {probs[0]*100:.1f}%")
    st.warning(f"🟨 Empate: {probs[1]*100:.1f}%")
    st.error(f"🟥 Vitória do {time_fora}: {probs[2]*100:.1f}%")
else:
    st.info("Selecione dois times diferentes para gerar a análise.")